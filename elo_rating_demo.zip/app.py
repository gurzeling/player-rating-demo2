import streamlit as st

st.title("🎾 Elo Rating Demo")

st.markdown("""
This app lets you simulate Elo rating updates using:
- **K = 8** (slow rating changes)
- Enter ratings for two players
- Select the winner
""")

# Inputs
Ra = st.number_input("Player A rating", min_value=600, max_value=3000, value=900)
Rb = st.number_input("Player B rating", min_value=600, max_value=3000, value=820)
winner = st.radio("Who won the match?", ["A", "B"])

# Elo update function
def update_elo(Ra, Rb, winner, K=8):
    expected_a = 1 / (1 + 10 ** ((Rb - Ra) / 400))
    result_a = 1 if winner == 'A' else 0
    result_b = 1 - result_a
    Ra_new = Ra + K * (result_a - expected_a)
    Rb_new = Rb + K * (result_b - (1 - expected_a))
    return round(Ra_new), round(Rb_new), round(expected_a * 100, 1)

# Button and result display
if st.button("Update Ratings"):
    Ra_new, Rb_new, expected = update_elo(Ra, Rb, winner)
    st.markdown(f"""
    ### 🎯 Result
    - Expected win chance for Player A: **{expected}%**
    - New rating for Player A: **{Ra_new}**
    - New rating for Player B: **{Rb_new}**
    """)
